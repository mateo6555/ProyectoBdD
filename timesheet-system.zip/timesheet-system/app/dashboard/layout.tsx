import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Clock, LayoutDashboard, LogOut, Users } from 'lucide-react'

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen flex">
      <aside className="w-64 bg-gray-900 text-white p-4">
        <div className="text-xl font-bold mb-8">TimeSheet App</div>
        <nav className="space-y-2">
          <Link href="/dashboard">
            <Button variant="ghost" className="w-full justify-start text-white">
              <LayoutDashboard className="mr-2 h-4 w-4" />
              Dashboard
            </Button>
          </Link>
          <Link href="/dashboard/timesheet">
            <Button variant="ghost" className="w-full justify-start text-white">
              <Clock className="mr-2 h-4 w-4" />
              Registro de Horas
            </Button>
          </Link>
          <Link href="/dashboard/employees">
            <Button variant="ghost" className="w-full justify-start text-white">
              <Users className="mr-2 h-4 w-4" />
              Empleados
            </Button>
          </Link>
        </nav>
        <div className="mt-auto pt-4">
          <Link href="/login">
            <Button variant="ghost" className="w-full justify-start text-white">
              <LogOut className="mr-2 h-4 w-4" />
              Cerrar Sesión
            </Button>
          </Link>
        </div>
      </aside>
      <main className="flex-1 p-8 bg-gray-50">
        {children}
      </main>
    </div>
  )
}

