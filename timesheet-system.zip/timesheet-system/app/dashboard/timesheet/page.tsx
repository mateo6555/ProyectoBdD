'use client'

import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function TimesheetPage() {
  const [entries, setEntries] = useState<Array<{
    date: string;
    project: string;
    hours: string;
    description: string;
  }>>([])

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)
    const newEntry = {
      date: formData.get('date') as string,
      project: formData.get('project') as string,
      hours: formData.get('hours') as string,
      description: formData.get('description') as string,
    }
    setEntries([...entries, newEntry])
    e.currentTarget.reset()
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Registro de Horas</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="date">Fecha</Label>
                <Input
                  id="date"
                  name="date"
                  type="date"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="project">Proyecto</Label>
                <Select name="project" required>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar proyecto" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="proyecto1">Proyecto 1</SelectItem>
                    <SelectItem value="proyecto2">Proyecto 2</SelectItem>
                    <SelectItem value="proyecto3">Proyecto 3</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="hours">Horas Trabajadas</Label>
                <Input
                  id="hours"
                  name="hours"
                  type="number"
                  min="0"
                  step="0.5"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Descripción</Label>
                <Input
                  id="description"
                  name="description"
                  required
                />
              </div>
            </div>
            <Button type="submit">Registrar Horas</Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Registros Recientes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">Fecha</th>
                  <th className="text-left p-2">Proyecto</th>
                  <th className="text-left p-2">Horas</th>
                  <th className="text-left p-2">Descripción</th>
                </tr>
              </thead>
              <tbody>
                {entries.map((entry, index) => (
                  <tr key={index} className="border-b">
                    <td className="p-2">{entry.date}</td>
                    <td className="p-2">{entry.project}</td>
                    <td className="p-2">{entry.hours}</td>
                    <td className="p-2">{entry.description}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

