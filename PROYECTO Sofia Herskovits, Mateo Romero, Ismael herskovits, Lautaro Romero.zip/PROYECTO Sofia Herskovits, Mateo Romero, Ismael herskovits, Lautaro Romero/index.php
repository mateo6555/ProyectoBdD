<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <title>Inicio</title>
  <style>
    /* Animación personalizada para el efecto de rebote */
    .animate-bounce:hover {
      animation: bounce 0.3s ease-in-out;
    }
    @keyframes bounce {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-5px); }
    }
  </style>
</head>
<body class="bg-gradient-to-br from-purple-100 to-indigo-200 min-h-screen flex items-center justify-center">

  <div class="w-full max-w-md p-8 bg-white rounded-lg shadow-lg text-center">
    <header class="mb-8">
      <h1 class="text-4xl font-extrabold text-gray-700">Matriz de Responsabilidades</h1>
    </header>

    <p class="text-gray-500 mb-8">
      Bienvenido a la plataforma para gestionar la asignación de desarrolladores a proyectos.
    </p>

    <div class="space-y-6">
      <div>
        <p class="text-sm text-gray-500 mb-2">¿Ya tienes una cuenta?</p>
        <a
          href="iniciar_sesion.php"
          class="block w-full py-3 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-500 transition duration-300 ease-in-out animate-bounce"
        >
          Iniciar sesión
        </a>
      </div>

      <div>
        <p class="text-sm text-gray-500 mb-2">¿Todavía no tienes una cuenta?</p>
        <a
          href="registro.php"
          class="block w-full py-3 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-500 transition duration-300 ease-in-out animate-bounce"
        >
          Registrarse
        </a>
      </div>
    </div>
  </div>

</body>
</html>
