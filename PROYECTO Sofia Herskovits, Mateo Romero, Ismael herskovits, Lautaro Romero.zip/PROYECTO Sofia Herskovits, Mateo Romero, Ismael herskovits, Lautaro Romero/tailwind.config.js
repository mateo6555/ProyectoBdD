module.exports = {
  content: ["./**/*.{html,php}"]
};