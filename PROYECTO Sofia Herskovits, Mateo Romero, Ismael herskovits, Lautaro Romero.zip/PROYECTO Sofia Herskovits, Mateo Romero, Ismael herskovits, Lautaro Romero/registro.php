<?php
include('conexion.php');

// Si existe "register" en el payload de POST, significa que se mando el form
if (isset($_POST['register'])) {
  // Agarro las variables que necesito
  $nombre = $_POST["nombre"];
  $apellido = $_POST["apellido"];
  $contraseña = $_POST["contraseña"];
  $email = $_POST["email"];

  // Ejecuto una query para encontrar algun usuario con el email ingresado
  $query = "SELECT * FROM usuarios WHERE email = '{$email}'";
  $result = $conexion->query($query);

  if ($result->num_rows > 0) {
    $conexion->close();
    // Si hay algun usuario con este email, muestro error
    $error = 'Ya existe un usuario con ese email';
  } else {   
    // Sino, inserto un nuevo usuario en la tabla "usuarios"
    $query = "INSERT INTO usuarios(nombre, apellido, contraseña, email) 
    VALUES ('{$nombre}', '{$apellido}', '{$contraseña}', '{$email}')";

    if ($conexion->query($query)) {
      // Agarro el id del usuario recien creado para la cookie
      $id = $conexion->insert_id;
      $conexion->close();
      // Guardo la cookie "usuario_logeado" con el usuario y el id separado por un ";"
      setcookie('usuario_logeado', "{$nombre};{$id}");
      // Y redirecciono a la matriz
      header('Location: matriz.php');
    } else {
      // Hubo un error al crear el usuario, muestro error
      $conexion->close();
      $error = 'Error al crear el usuario';
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <title>Registro</title>
  <style>
    /* Animación de escala para los botones */
    .scale-hover:hover {
      transform: scale(1.05);
    }
  </style>
</head>
<body class="bg-gradient-to-r from-gray-50 to-blue-100 min-h-screen">

  <header class="w-full h-16 mb-12 shadow-lg flex justify-center items-center bg-gradient-to-r from-teal-500 to-cyan-600">
    <h1 class="pb-1 text-3xl font-extrabold text-white">Matriz de Responsabilidades</h1>
  </header>

  <form action="registro.php" method="POST" class="w-[500px] mx-auto p-8 bg-white shadow-xl rounded-2xl">
    <h2 class="mb-8 text-2xl font-semibold text-center text-gray-700">Registro</h2>

    <div class="mb-4">
      <label for="nombre" class="block mb-1 text-gray-600">Nombre</label>
      <input
        id="nombre"
        name="nombre"
        class="w-full px-3 py-2 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-teal-500 transition-colors"
        maxlength="50"
        required
      />
    </div>

    <div class="mb-4">
      <label for="apellido" class="block mb-1 text-gray-600">Apellido</label>
      <input
        id="apellido"
        name="apellido"
        class="w-full px-3 py-2 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-teal-500 transition-colors"
        maxlength="50"
        required
      />
    </div>

    <div class="mb-4">
      <label for="email" class="block mb-1 text-gray-600">Email</label>
      <input
        id="email"
        name="email"
        type="email"
        class="w-full px-3 py-2 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-teal-500 transition-colors"
        maxlength="50"
        required
      />
    </div>

    <div class="mb-6">
      <label for="contraseña" class="block mb-1 text-gray-600">Contraseña</label>
      <input
        id="contraseña"
        name="contraseña"
        type="password"
        class="w-full px-3 py-2 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-teal-500 transition-colors"
        maxlength="50"
        required
      />
    </div>

    <input
      type="submit"
      class="w-full py-3 mb-3 bg-teal-500 hover:bg-teal-400 text-white font-semibold rounded-xl transition-transform cursor-pointer scale-hover"
      value="Registrarme"
      name="register"
    />

    <a href="index.php" class="block w-full py-3 bg-gray-200 text-center rounded-xl text-gray-700 font-semibold hover:bg-gray-300 transition-colors scale-hover">
      Atrás
    </a>

    <p class="mt-4 text-red-600 text-center">
      <?php echo $error ?? ''; ?>
    </p>
  </form>
</body>
</html>
