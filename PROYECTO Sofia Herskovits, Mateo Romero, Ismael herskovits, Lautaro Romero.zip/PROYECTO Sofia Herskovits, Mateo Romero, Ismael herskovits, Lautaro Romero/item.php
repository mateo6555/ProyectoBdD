<?php
include('conexion.php');

// Si la cookie "usuario_logeado" esta vacia, lo devuelvo al index
if(empty($_COOKIE['usuario_logeado'])) {
  header('Location: index.php');
}

// Si no se paso un "id" en la url, lo devuelvo a la matriz
if (!isset($_GET['id']) || $_GET['id'] == '') {
  header('Location: matriz.php');
}

// Agarro el id_matriz del parametro "id"
$id_matriz = $_GET['id'];
// Si el id_matriz es "add", significa que esta agregando un item
$agregando = $id_matriz == 'add';
// Agarro la cookie, la separo por ";" y agarro el primer valor, asi muestro el usuario
$cookie = explode(";", $_COOKIE['usuario_logeado']);
$id_usuario = $cookie[1];

// Si no esta agregando, traigo el item que esta queriendo editar y lo guardo en $item
if (!$agregando) {
  $query = "SELECT * FROM matriz WHERE id = {$id_matriz} AND id_usuario = {$id_usuario}";
  $result = $conexion->query($query);

  if ($result->num_rows > 0) {
    $item = $result->fetch_assoc();
  }
}

// Si existe "save" en el payload de POST, significa que se mando el form
if (isset($_POST['save'])) {
  // Agarro las variables que necesito
  $actividades = $_POST["actividades"];
  $encargado = $_POST["encargado"];
  $nombre_proyecto = $_POST["nombre_proyecto"];
  
  // Si esta agregando, la query va a ser un INSERT
  if ($agregando) {
    $query = "INSERT INTO matriz(id_usuario, actividades, encargado, nombre_proyecto) 
    VALUES ('{$id_usuario}', '{$actividades}', '{$encargado}', '{$nombre_proyecto}')";
  } else {
    // Sino, va a ser un UPDATE
    $query = "UPDATE matriz 
              SET actividades = '{$actividades}', 
                  encargado = '{$encargado}', 
                  nombre_proyecto = '{$nombre_proyecto}' 
              WHERE id = '{$id_matriz}' AND id_usuario = '{$id_usuario}'";
  }

  // Ejecuto la query
  if ($conexion->query($query)) {
    $conexion->close();
    // Y redirecciono a la matriz
    header('Location: matriz.php');
  } else {
    // Hubo un error al guardar, muestro error
    $conexion->close();
    $error = 'Error al guardar los cambios';
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <title>Item</title>
  <style>
    /* Animación de rebote para los botones */
    .animate-bounce:hover {
      animation: bounce 0.3s ease-in-out;
    }
    @keyframes bounce {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-4px); }
    }
  </style>
</head>
<body class="bg-gradient-to-br from-gray-100 to-blue-100 min-h-screen flex items-center justify-center">

  <div class="w-full max-w-md p-8 bg-white rounded-lg shadow-lg shadow-indigo-200">
    <header class="mb-8 text-center">
      <h1 class="text-3xl font-extrabold text-gray-700">Matriz de Responsabilidades</h1>
    </header>

    <form method="POST" class="space-y-6">
      <h2 class="text-2xl font-semibold text-gray-800 text-center mb-6">
        <?php echo $agregando ? 'Agregar item' : 'Editar item'; ?>
      </h2>
      
      <div>
        <label for="actividades" class="block text-sm text-gray-500 mb-1">Actividades</label>
        <input
          id="actividades"
          name="actividades"
          class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
          value="<?php echo htmlspecialchars($item['actividades'] ?? ''); ?>"
          maxlength="1000"
          required
        />
      </div>
      
      <div>
        <label for="encargado" class="block text-sm text-gray-500 mb-1">Encargado</label>
        <input
          id="encargado"
          name="encargado"
          class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
          value="<?php echo htmlspecialchars($item['encargado'] ?? ''); ?>"
          maxlength="50"
          required
        />
      </div>
      
      <div>
        <label for="nombre_proyecto" class="block text-sm text-gray-500 mb-1">Proyecto asignado</label>
        <input
          id="nombre_proyecto"
          name="nombre_proyecto"
          class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
          value="<?php echo htmlspecialchars($item['nombre_proyecto'] ?? ''); ?>"
          maxlength="50"
          required
        />
      </div>
      
      <input
        type="submit"
        class="w-full py-3 <?php echo $agregando ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-sky-600 hover:bg-sky-500'; ?> text-white font-semibold rounded-lg transition duration-300 ease-in-out animate-bounce cursor-pointer"
        value="Guardar"
        name="save"
      />
      
      <a href="matriz.php" class="block w-full py-3 mt-2 bg-gray-100 text-gray-600 text-center rounded-lg hover:bg-gray-200 transition duration-300">
        Atrás
      </a>
      
      <?php if (isset($error)): ?>
        <p class="mt-4 text-center text-red-600 font-medium"><?php echo $error; ?></p>
      <?php endif; ?>
    </form>
  </div>

</body>
</html>
